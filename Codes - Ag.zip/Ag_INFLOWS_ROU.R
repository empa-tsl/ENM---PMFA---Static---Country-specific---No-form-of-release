# Script that performs a Monte-Carlo MFA Calculation
# =================================================================================================
# 
# Required input:     - TC : a matrix containing all the modal transfer coefficients from one 
#                       compartment to another (assuming that all these TC will have triangular 
#                       distributions)
#                     - UC : a matrix containing all the uncertainty coefficients associated with
#                       transfer coefficients
# 
# Output:   - Mass : a matrix containing the masses of the substances in each compartment
# =================================================================================================

# source needed functions
source("functions.needed.R")

require(mc2d)

##### INTRO #######################################################################################
timer <- proc.time() # first timer to check how long the simulation was running
SIM <- 100000 # set number of simulation steps

#########DEFINE THE PRODUCTION DISTRIBUTION #######################################################
enmprod_data <- read.csv("nano_Ag_production2000-2030.csv", header = F)

enmproduction <- enmprod_data[,15]*0.1
enmproduction <- sample(enmproduction, SIM, replace = T)

#Scaling down.
SF_Prod <- 0
SF_Prod_Distr <- runif (SIM, 0, 0.02)

enmprod_ROU <- enmproduction*SF_Prod_Distr
hist(enmprod_ROU)

##### DEFINE TC matrix and ini.input vector #######################################################

### DEFINE THE TRANSFER COEFFICIENT MATRIX TC (flows from column to rows)
TC <- read.table(file = "TC_AG_ROU.csv", header = TRUE, sep = ",", row.names = 1)
TC <- as.matrix(TC)
               
# define uncertainty matrix
TC.uncertainty <- read.table (file = "UC_AG_ROU.csv", header = TRUE, sep = ",", row.names = 1)
TC.uncertainty <- as.matrix(TC.uncertainty)

# define scaling factors and imports

SF_Manuf <- 0.0041
SF_Manuf_Distr <- rtriang.perc(mmode = SF_Manuf, perc = 0.34, N = SIM, do.trunc = c(0,1))

SF_Cons <- 0.0111
SF_Cons_Distr <- rtriang.perc(mmode = SF_Cons, perc = 0.55, N = SIM, do.trunc = c(0,1))

Import_Manuf <- SF_Manuf_Distr*enmproduction - SF_Prod_Distr*enmproduction
Import_Manuf <- Import_Manuf[Import_Manuf >= 0]
Import_Manuf <- sample(Import_Manuf, SIM, replace = T)

Import_Cons <- SF_Cons_Distr*enmproduction*3 - SF_Manuf_Distr*enmproduction

### define the initial input vector, i.e. in which compartments there is an input
inp.Distr <- rbind(Import_Manuf, Import_Cons, enmprod_ROU, matrix(0,82,SIM)) 

# give the vectors names (optional)
dimnames(inp.Distr)[[1]] <- dimnames(TC)[[1]]

### SOME TESTS TO INSURE CONSISTENT DATA
# stop calculation if the matrix is not square with symmetric dimnames
if(!all(colnames(TC) == rownames(TC))){
  warning("The column and row names of TC are not identical. Make sure the input is correct.")
}

##### CREATE A TC MATRIX AND INPUT VECTOR FOR EVERY SIMULATION STEP ###############################

TC.Distr <- triangulize.TC(modalvalues = TC, uncertainty = TC.uncertainty, N = SIM, do.trunc = c(0,1))

# define custom distributions here:

# EMISSIONS FROM PRODUTION AND MANUFACTURING

TC_PROD_WW <- rtriang(SIM, min = 0.0002, mode = 0.0125, max = 0.0467)

TC_MANUF_ELECTRPRINT_WW <- runif(SIM, min = 0, max = 0.000001)
TC_MANUF_OTHER_WW <- rtriang(SIM, min = 0.0025, mode = 0.005, max = 0.0075)
TC_MANUF_WW <- c(sample(TC_MANUF_ELECTRPRINT_WW, 0.8*SIM), sample(TC_MANUF_OTHER_WW, 0.2*SIM))

TC.Distr[["Production"]][["Prod_WW"]] <- TC_PROD_WW
TC.Distr[["Manufacturing"]][["Manuf_WW"]] <- TC_MANUF_WW

# OTHER CUSTOM TCs

TC.Distr[["C_Medical"]][["Medical_WW"]] <- runif(SIM, min = 0, max = 0.01)
TC.Distr[["C_ElectrAppl"]][["ElectrAppl_WW"]] <- runif(SIM, min = 0, max = 0.01)

## define water untreated due to overflow

OF <- c(rnorm(SIM,0.032,0.004))

TC.Distr[["Wastewater"]][["Surfacewater"]] <- OF
TC.Distr[["Wastewater"]][["STP"]] <- 1-OF

# define removal efficiency for dissolved, transformed and nano:

TCstp_tr_slud_Kiser1_2012 <- c(runif(20000,0.40,0.62))
TCstp_tr_slud_Kiser2_2012 <- c(runif(20000,0.50,0.60))
TCstp_tr_slud_Hou2012     <- c(runif(40000,0.99,1.00))
TCstp_tr_slud_Tiede2010	  <- c(runif(40000,0.90,1.00))
TCstp_tr_slud_Wang2012	  <- c(runif(40000,0.88,0.88))
TCstp_tr_slud_Kiser2010   <- c(runif(40000,0.39,0.97))
TCstp_tr_slud_Kaegi2011   <- c(runif(60000,0.97,0.97))

TCstp_tr_slud <-c(TCstp_tr_slud_Kiser1_2012,TCstp_tr_slud_Kiser2_2012,TCstp_tr_slud_Hou2012,TCstp_tr_slud_Tiede2010,TCstp_tr_slud_Wang2012,
                  TCstp_tr_slud_Kiser2010,TCstp_tr_slud_Kaegi2011)
TCstp_tr_slud <- sample(TCstp_tr_slud, 100000, replace=T)

RE <- TCstp_tr_slud

# So:

RE <- rep(0, SIM)
for (i in 1:length(TCstp_tr_slud)){
  if (TCstp_tr_slud[i] <= 1){
    RE[i] <- TCstp_tr_slud[i]
  }
}

# Define associated distributions:
TC.Distr[["STP"]][["Surfacewater"]] <- 1-RE
TC.Distr[["STP"]][["Sludge"]] <- RE

# make sure there are no undefined values
stopifnot(!any(is.na(TC.Distr)), !any(is.na(inp.Distr)))

# normalization step: make sure that all the flows going out of a compartment sum up to 1
TC.Distr.Norm <- normalize(Distr = TC.Distr)

# make sure there are no undefined values in the code
stopifnot(!any(is.na(TC.Distr.Norm)))

##### SOLVE EQUATION ##############################################################################
# create an empty matrix to contain the mass distributions for every compartment
Mass <- solve.MC(TC.Distr = TC.Distr.Norm,
                 inp.Distr = inp.Distr,
                 N = SIM)

# notify how long was needed for the whole calculation
message("Time needed for the simulation:")
print(proc.time() - timer) # second timer

##### RETRIEVES VALUES ###########################################################################

###Flows (preparing the data)

Mode_Y	<- function(x)
{
  dens	<- density(x)
  ind		<- which(dens$y==max(dens$y))
  dens$x[ind]
}

flows <- matrix(NA,85,5)

for(i in 1:85)
{
  xx			<- Mass[i,]
  
  flows[i,1]	<- i
  flows[i,2]	<- quantile(xx,0.25)
  flows[i,3]	<- Mode_Y(xx)[1]
  flows[i,4]	<- mean(xx)
  flows[i,5]	<- quantile(xx,0.75)	
}

####################
###Exporting. Provide the desired name and folder
####################

measures			<- rbind(flows)
colnames(measures)	<- c("Row","Q25","Mode","Mean","Q75")
measures_table		<- as.table(measures)
write.table(measures_table,"Ag_IN_ROU.csv")

###### GRAPHS #####################################################################################

# saves a pdf file of the histograms of the distributions to the working directory
pdf(file = "Output_of_Ag_ROU.pdf",
    height = 7.5,
    width = 7.5,
    pointsize = 10)
par(mfrow = c(3,3), mar = c(3,3,3,1), mgp= c(1.5,0.5,0), xpd = F)
color <- c(rep("aquamarine", 3), rep("cornsilk2", 4), rep("darksalmon", 2))
for(co in 1:dim(Mass)[1]){
  hist(Mass[co,], freq = F, xlab = paste(dimnames(Mass)[[1]][co], "(kt)"),
       ylab = "Probability density", main = dimnames(Mass)[[1]][co],
       col = color[co])
  box()
}
dev.off()
