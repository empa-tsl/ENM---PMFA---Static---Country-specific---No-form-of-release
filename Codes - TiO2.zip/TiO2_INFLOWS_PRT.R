# Script that performs a Monte-Carlo MFA Calculation
# =================================================================================================
# 
# Required input:     - TC : a matrix containing all the modal transfer coefficients from one 
#                       compartment to another (assuming that all these TC will have triangular 
#                       distributions)
#                     - UC : a matrix containing all the uncertainty coefficients associated with
#                       transfer coefficients
# 
# Output:   - Mass : a matrix containing the masses of the substances in each compartment
# =================================================================================================

# source needed functions
source("functions.needed.R")

require(mc2d)

##### INTRO #######################################################################################
timer <- proc.time() # first timer to check how long the simulation was running
SIM <- 35000 # set number of simulation steps

#########DEFINE THE PRODUCTION DISTRIBUTION #######################################################
enmprod_data <- read.csv("nano_TiO2production2000-2030.csv", header = F)

enmproduction <- enmprod_data[,15]
enmproduction <- sample(enmproduction, SIM, replace = T)

#Scaling down.
SF_Prod <- 0
SF_Prod_Distr <- runif (SIM, 0, 0)

enmprod_PRT <- enmproduction*SF_Prod_Distr
hist(enmprod_PRT)

##### DEFINE TC MATRIX AND INPUT VECTOR #######################################################

### DEFINE THE TRANSFER COEFFICIENT MATRIX TC (flows from column to rows)
TC <- read.table(file = "TC_TIO2_PRT.csv", header = TRUE, sep = ",", row.names = 1)
TC <- as.matrix(TC)
               
# define uncertainty matrix
TC.uncertainty <- read.table (file = "UC_TIO2_PRT.csv", header = TRUE, sep = ",", row.names = 1)
TC.uncertainty <- as.matrix(TC.uncertainty)

# define scaling factors and imports

SF_Manuf <- 0.0134
SF_Manuf_Distr <- rtriang.perc(mmode = SF_Manuf, perc = 0.22, N = SIM, do.trunc = c(0,1))

SF_Cons <- 0.022
SF_Cons_Distr <- rtriang.perc(mmode = SF_Cons, perc = 0.34, N = SIM, do.trunc = c(0,1))

Import_Manuf <- SF_Manuf_Distr*enmproduction - SF_Prod_Distr*enmproduction
Import_Manuf <- Import_Manuf[Import_Manuf >= 0]
Import_Manuf <- sample(Import_Manuf, SIM, replace = T)

Import_Cons <- SF_Cons_Distr*enmproduction - SF_Manuf_Distr*enmproduction
Import_Cons <- Import_Cons[Import_Cons >= 0]
Import_Cons <- sample(Import_Cons, SIM, replace = T)
  
### define the initial input vector, i.e. in which compartments there is an input
inp.Distr <- rbind(Import_Manuf, Import_Cons, enmprod_PRT, matrix(0, 89, SIM)) 

# give the vectors names (optional)
dimnames(inp.Distr)[[1]] <- dimnames(TC)[[1]]

### SOME TESTS TO INSURE CONSISTENT DATA
# stop calculation if the matrix is not square with symmetric dimnames
if(!all(colnames(TC) == rownames(TC))){
  warning("The column and row names of TC are not identical. Make sure the input is correct.")
}

##### CREATE A TC MATRIX FOR EVERY SIMULATION STEP ###############################

TC.Distr <- triangulize.TC(modalvalues = TC, uncertainty = TC.uncertainty, N = SIM, do.trunc = c(0,1))

# define custom distributions here:

# EMISSIONS FROM PRODUTION AND MANUFACTURING
TC_PROD_AIR <- rtriang.perc(mmode = 0.0000016, perc = 0.5, N = SIM, do.trunc = c(0,1))
TC_PROD_WW <- rtriang(SIM, min = 0.0002, mode = 0.0125, max = 0.0467)
TC_MANUF_AIR <- rtriang.perc(mmode = 0.0000017, perc = 0.5, N = SIM, do.trunc = c(0,1))
TC_MANUF_WW <- runif(SIM, min = 0.001, max = 0.0016)

TC.Distr[["Production"]][["Prod_WW"]] <- TC_PROD_WW
TC.Distr[["Production"]][["Prod_Air"]] <- TC_PROD_AIR

TC.Distr[["Manufacturing"]][["Manuf_WW"]] <- TC_MANUF_WW
TC.Distr[["Manufacturing"]][["Manuf_Air"]] <- TC_MANUF_AIR

# NEW PRODUCT ALLOCATIONS
TC.Distr[["Manufacturing"]][["M_PersCare"]] <- rtriang(SIM, min = 0.72, mode = 0.7664, max = 0.81)
TC.Distr[["Manufacturing"]][["M_Paints"]] <- rtriang(SIM, min = 0, mode = 0.0506, max = 0.1)
TC.Distr[["Manufacturing"]][["M_Food"]] <- rtriang(SIM, min = 0, mode = 0.0481, max = 0.14)
TC.Distr[["Manufacturing"]][["M_Cement"]] <- rtriang(SIM, min = 0, mode = 0.0285, max = 0.0525)
TC.Distr[["Manufacturing"]][["M_CoatGlass"]] <- rtriang(SIM, min = 0, mode = 0.0285, max = 0.0525)
TC.Distr[["Manufacturing"]][["M_CoatCeramic"]] <- rtriang(SIM, min = 0, mode = 0.0285, max = 0.0525)
TC.Distr[["Manufacturing"]][["M_PlasAdd"]] <- rtriang(SIM, min = 0, mode = 0.0232, max = 0.05)
TC.Distr[["Manufacturing"]][["M_Electronics"]] <- rtriang(SIM, min = 0.005, mode = 0.0182, max = 0.03)
TC.Distr[["Manufacturing"]][["M_CleaningAgents"]] <- rtriang(SIM, min = 0, mode = 0.0083, max = 0.02)
TC.Distr[["Manufacturing"]][["M_Solar"]] <- rtriang(SIM, min = 0, mode = 0.0033, max = 0.01)
TC.Distr[["Manufacturing"]][["M_Textiles"]] <- rtriang(SIM, min = 0, mode = 0.0017, max = 0.005)

TC.Distr[["Consumption"]][["C_PersCare"]] <- rtriang(SIM, min = 0.72, mode = 0.76, max = 0.81)
TC.Distr[["Consumption"]][["C_Paints"]] <- rtriang(SIM, min = 0, mode = 0.0508, max = 0.1)
TC.Distr[["Consumption"]][["C_Food"]] <- rtriang(SIM, min = 0, mode = 0.0483, max = 0.14)
TC.Distr[["Consumption"]][["C_Cement"]] <- rtriang(SIM, min = 0, mode = 0.0286, max = 0.0525)
TC.Distr[["Consumption"]][["C_CoatGlass"]] <- rtriang(SIM, min = 0, mode = 0.0286, max = 0.0525)
TC.Distr[["Consumption"]][["C_CoatCeramic"]] <- rtriang(SIM, min = 0, mode = 0.0286, max = 0.0525)
TC.Distr[["Consumption"]][["C_PlasAdd"]] <- rtriang(SIM, min = 0, mode = 0.0233, max = 0.05)
TC.Distr[["Consumption"]][["C_Electronics"]] <- rtriang(SIM, min = 0.005, mode = 0.0183, max = 0.03)
TC.Distr[["Consumption"]][["C_CleaningAgents"]] <- rtriang(SIM, min = 0, mode = 0.0083, max = 0.02)
TC.Distr[["Consumption"]][["C_Solar"]] <- rtriang(SIM, min = 0, mode = 0.0033, max = 0.01)
TC.Distr[["Consumption"]][["C_Textiles"]] <- rtriang(SIM, min = 0, mode = 0.0017, max = 0.005)

## define water untreated due to overflow

OF <- c(rnorm(SIM,0.032,0.004))

TC.Distr[["Wastewater"]][["Surfacewater"]] <- OF
TC.Distr[["Wastewater"]][["STP"]] <- 1-OF

# define removal efficiency for dissolved, transformed and nano:

TCstp_tr_slud_Kiser2009 <- c(runif(50000,0.20,0.64))
TCstp_tr_slud_Johnson2011 <- c(runif(50000,0.895,0.895))

TCstp_tr_slud_Limbach2008 <- c(runif(30000,0.95,0.98))
TCstp_tr_slud_Zhang2008 <- c(runif(30000,0.80,0.98))

TCstp_tr_slud_Kiser2010 <- c(runif(20000,0.23,0.23))
TCstp_tr_slud_Wang2011 <- c(runif(20000,0.95,0.95))
TCstp_tr_slud_Gomez_Rivera2012 <- c(runif(20000,0.985,0.985))
TCstp_tr_slud_Hwang2011 <- c(runif(20000,0.913,0.913))

TCstp_tr_slud <-c(TCstp_tr_slud_Kiser2009, TCstp_tr_slud_Johnson2011, TCstp_tr_slud_Limbach2008,TCstp_tr_slud_Zhang2008, TCstp_tr_slud_Kiser2010,
                  TCstp_tr_slud_Wang2011,TCstp_tr_slud_Gomez_Rivera2012, TCstp_tr_slud_Hwang2011)

TCstp_tr_slud <- sample(TCstp_tr_slud,100000,replace = TRUE)

# So:

RE <- TCstp_tr_slud

# Define associated distributions:

TC.Distr[["STP"]][["Surfacewater"]] <- 1-RE
TC.Distr[["STP"]][["Sludge"]] <- RE

# make sure there are no undefined values
stopifnot(!any(is.na(TC.Distr)), !any(is.na(inp.Distr)))

# normalization step: make sure that all the flows going out of a compartment sum up to 1
TC.Distr.Norm <- normalize(Distr = TC.Distr)

# make sure there are no undefined values in the code
stopifnot(!any(is.na(TC.Distr.Norm)))

##### SOLVE EQUATION ##############################################################################
# create an empty matrix to contain the mass distributions for every compartment
Mass <- solve.MC(TC.Distr = TC.Distr.Norm,
                     inp.Distr = inp.Distr,
                     N = SIM)

# notify how long was needed for the whole calculation
message("Time needed for the simulation:")
print(proc.time() - timer) # second timer

##### RETRIEVES VALUES ###########################################################################

###Flows (preparing the data)

Mode_Y	<- function(x)
{
  dens	<- density(x)
  ind		<- which(dens$y==max(dens$y))
  dens$x[ind]
}

flows <- matrix(NA,92,5)

for(i in 1:92)
{
  xx			<- Mass[i,]
  
  flows[i,1]	<- i
  flows[i,2]	<- quantile(xx,0.25)
  flows[i,3]	<- Mode_Y(xx)[1]
  flows[i,4]	<- mean(xx)
  flows[i,5]	<- quantile(xx,0.75)	
}

####################
###Exporting. Provide the desired name and folder
####################

measures			<- rbind(flows)
colnames(measures)	<- c("Row","Q25","Mode","Mean","Q75")
measures_table		<- as.table(measures)
write.table(measures_table,"TiO2_IN_PRT.csv")

###### GRAPHS #####################################################################################

# saves a pdf file of the histograms of the distributions to the working directory
pdf(file = "Output_of_TiO2_PRT.pdf",
    height = 7.5,
    width = 7.5,
    pointsize = 10)
par(mfrow = c(3,3), mar = c(3,3,3,1), mgp= c(1.5,0.5,0), xpd = F)
color <- c(rep("aquamarine", 3), rep("cornsilk2", 4), rep("darksalmon", 2))
for(co in 1:dim(Mass)[1]){
  hist(Mass[co,], freq = F, xlab = paste(dimnames(Mass)[[1]][co], "(t)"),
       ylab = "Probability density", main = dimnames(Mass)[[1]][co],
       col = color[co])
  box()
}
dev.off()
